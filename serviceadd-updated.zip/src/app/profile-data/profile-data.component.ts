import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-profile-data',
  templateUrl: './profile-data.component.html',
  styleUrls: ['./profile-data.component.css']
})
export class ProfileDataComponent implements OnInit {
  cashortname:any;
  commonname:any;
  creationdate:any;
  expirationdate:any;
  regformstatus:any;
  regformtag:any;

  constructor() { }

  ngOnInit(): void {
    this.cashortname = localStorage.getItem('cashortname');
    this.commonname = localStorage.getItem('commonname');
    this.creationdate = localStorage.getItem('creationdate');
    this.expirationdate = localStorage.getItem('expirationdate');
    this.regformstatus = localStorage.getItem('regformstatus');
    this.regformtag = localStorage.getItem('regformtag');
  }

}
