import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Inject, Injectable } from '@angular/core';
import { SESSION_STORAGE, StorageService } from 'ngx-webstorage-service';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';

const httpOption = {
  headers: new HttpHeaders({
  'Access-Control-Allow-Origin': '*',
  'Content-Type': 'application/json; charset=utf-8',
  "X-Requested-With": "XMLHttpRequest"})
};

@Injectable({
  providedIn: 'root'
})
export class ServiceService {

  httpclient: any;
  constructor( @Inject(SESSION_STORAGE) private storage: StorageService, private http:HttpClient ) {
    
   }

  private handleError<T> (operation = 'operation', result?: T) {
    return (error:any):Observable<T> => {
      return of(result as T);
    };
  }

  /* */
  profileFormsubmit(postData:any):Observable<any> { 
    let apiUrl = 'https://localhost:8080/notificationdetails';
    return this.http.post(apiUrl,postData,httpOption).pipe(map(result=>result));
  }
  bulkuploadsubmit(postData:any):Observable<any> { 
    let apiUrl = 'https://localhost:8080/bulkuploadnotificationdetails';
    return this.http.post(apiUrl,postData,httpOption).pipe(map(result=>result));
  }
}
