import { Route } from '@angular/router';
import { ProfileinfoComponent } from 'app/modules/admin/pages/profileinfo/profileinfo.component';

export const profileinfoRoutes: Route[] = [
    {
        path     : '',
        component: ProfileinfoComponent
    }
];
