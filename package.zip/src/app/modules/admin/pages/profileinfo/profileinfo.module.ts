import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { TreoCardModule } from '@treo/components/card';
import { SharedModule } from 'app/shared/shared.module';
import { ProfileinfoComponent } from 'app/modules/admin/pages/profileinfo/profileinfo.component';
import { profileinfoRoutes } from 'app/modules/admin/pages/profileinfo/profileinfo.routing';
//
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';

@NgModule({
    declarations: [
        ProfileinfoComponent
    ],
    imports     : [
        RouterModule.forChild(profileinfoRoutes),
        MatButtonModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatInputModule,
        MatMenuModule,
        MatTooltipModule,
        TreoCardModule,
        SharedModule,
        
        MatSortModule,
        MatPaginatorModule,
        MatTableModule,
        MatToolbarModule,
        MatCheckboxModule,
        MatRadioModule,
        MatSelectModule
    ]
})
export class ProfileinfoModule
{
}
