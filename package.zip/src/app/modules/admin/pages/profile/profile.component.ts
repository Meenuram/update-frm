import { ChangeDetectionStrategy, Component, ViewEncapsulation, OnInit } from '@angular/core';
// import {VERSION} from '@angular/material';

@Component({
    selector       : 'profile',
    templateUrl    : './profile.component.html',
    styleUrls      : ['./profile.component.scss'],
    encapsulation  : ViewEncapsulation.None,
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileComponent implements OnInit
{
    infodetails: Boolean= true;
    uploaddetails: Boolean= false;
    // version = VERSION;
  base64File: string = null;
  filename: string = null;
  fileToUpload: File | null = null;
  router: any;
    /**
     * Constructor
     */
    constructor()
    {
        this.infodetails= true;
        this.uploaddetails= false;
    }
    ngOnInit() {
        
    }
    handleFileInput(files: FileList) {
      this.fileToUpload = files.item(0);
    }
    singleuploadbtn() {
        this.infodetails= true;
        this.uploaddetails= false;
    }
    bulkuploadbtn() {
        this.infodetails= false;
        this.uploaddetails= true;
    }
    saveData(){
      window.open("/pages/profileinfo");
    }
}
