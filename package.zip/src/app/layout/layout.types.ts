export type Layout = 'empty' |
    'centered' | 'enterprise' | 'material' | 'modern' |
    'basic' | 'classic' | 'classy' | 'compact' | 'dense' | 'futuristic' | 'thin';
