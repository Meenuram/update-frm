import { InjectionToken } from '@angular/core';

export const TREO_APP_CONFIG = new InjectionToken<any>('Default configuration for the app');
